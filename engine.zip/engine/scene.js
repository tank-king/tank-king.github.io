import {BaseStructure} from "./base";

class Scene extends BaseStructure {
    constructor(manager, name) {
        super();
        this.name = name;
        this.manager = manager;
    }

    init() {

    }

    enter() {

    }

    exit() {
    }

    reset() {
        this.init();
    }

    update(events, dt) {

    }

    draw(offset, scale) {
    }
}