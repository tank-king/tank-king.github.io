Point = Vector

function range(start, end, step = 1) {
    const length = Math.floor((end - start) / step);
    return Array.from({length}, (_, index) => start + index * step);
}