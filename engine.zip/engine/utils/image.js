import {Singleton} from "../base";

class AssetManager extends Singleton {
    constructor() {
        super();
        this.images = {};
        this.fonts = {};
        this.sounds = {};
    }

    load_image(path) {
        const img = loadImage(
            path,
            (_image) => console.log('loaded image ' + path),
            (ev) => console.log('ERROR: cannot load ' + path + '\n' + ev),
        );
        this.images[path] = img;
        return img;
    }

    load_sound(path) {
        const sound = loadSound(
            path,
            () => console.log('loaded sound ' + path),
            () => console.log('ERROR: cannot load ' + path),
        );
        this.sounds[path] = sound;
        return sound;
    }

    load_font(path) {
        const font = loadFont(
            path,
            () => console.log('loaded font ' + path),
            () => console.log('ERROR: cannot load ' + path),
        );
        this.fonts[path] = font;
        return font;
    }

    image(path) {
        try {
            return this.images[path];
        }
        catch (e){
            return this.load_image(path);
        }
    }

    font(path){
        try {
            return this.fonts[path];
        }
        catch (e){
            return this.load_font(path);
        }
    }

    sound(path){
        try {
            return this.sounds[path];
        }
        catch (e){
            return this.load_sound(path);
        }
    }
}

class SpriteSheet{
    constructor(sheet, rows, cols, images, scale, flipped) {
        const assetManagerSingleton = new AssetManager();
        this.sheet = assetManagerSingleton.load_image(sheet);
    }
}