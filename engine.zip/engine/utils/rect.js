class Rect {
    constructor(x = 0, y = 0, w = 0, h = 0) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    collide_rect(other) {
        let colliding = true;
        if (
            this.x > other.x + other.w ||
            this.x + this.w < other.x ||
            this.y > other.y + other.h ||
            this.y + this.h < other.y
        ) {
            colliding = false;
        }
        return colliding;
    }

    collide_point(x, y) {
        if (this.x <= x && this.x <= this.x + this.w) {
            if (this.y <= y && y <= this.y + this.h) {
                return true;
            }
        }
        return false;
    }
}