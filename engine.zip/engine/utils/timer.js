function get_time() {
    return Date.now() * 0.001; // in seconds
}

class Timer {
    constructor(timeout = 0.0, reset = true, callback = null) {
        this.timeout = timeout;
        this.timer = get_time();
        this.paused_timer = get_time();
        this.paused = false;
        this._reset = reset;
        this._callback = callback;
        this.done = false;
    }

    set_timeout(timeout) {
        this.timeout = timeout;
    }

    set_callback(func) {
        this._callback = func;
    }

    reset() {
        this.timer = get_time();
    }

    pause() {
        this.paused = true;
        this.paused_timer = get_time();
    }

    resume() {
        this.paused = false;
        this.timer -= get_time() - this.paused_timer;
    }

    elapsed() {
        if (this.paused) {
            return get_time() - this.timer - (get_time() - this.paused_timer);
        }
        return get_time() - this.timer;
    }

    tick() {
        if (this.done === true) {
            return false;
        }
        if (this.elapsed() > this.timeout) {
            if (this._reset) {
                this.reset();
            } else {
                this.done = true;
            }
            if (this._callback != null) {
                this._callback();
            }
            return true;
        } else {
            return false;
        }
    }
}


class InfiniteTimer extends Timer {
    constructor() {
        super();
        this.done = true;
    }
}