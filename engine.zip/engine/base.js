class BaseStructure {
    update(events, dt) {
    }

    draw(offset, scale) {
    }
}


class Singleton {
    static __instance;

    constructor() {
        return Singleton.instance();
    }

    static instance() {
        if (Singleton.__instance != null) {
            return Singleton.__instance;
        }
        return new Singleton();
    }
}

export {
    BaseStructure, Singleton,
}